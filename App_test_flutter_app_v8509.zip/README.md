
# test_flutter_app

테스트용 Flutter 애플리케이션

## Getting Started

This is a Flutter application.

### Prerequisites

- Flutter SDK
- Dart

### Running the application

1. Run `flutter pub get` to install dependencies
2. Run `flutter run` to start the application

## Features

- [Add your features here]
