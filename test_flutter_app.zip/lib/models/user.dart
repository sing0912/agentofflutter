
class User {
  final String id;
  final String name;
  final String email;
  final DateTime createdAt;

  User({
    this.id,
    this.name,
    this.email,
    this.createdAt,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      // TODO: 구현
    );
  }

  Map<String, dynamic> toJson() {
    return {
      // TODO: 구현
    };
  }
}
